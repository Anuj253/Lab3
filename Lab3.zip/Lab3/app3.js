// Import necessary modules
const express = require('express');
const fs = require('fs');
const path = require('path');

// Create an instance of an Express application
const app = express();

// Use middleware to parse JSON request bodies
app.use(express.json());

// Define a port number
const PORT = 3000;

// Define a route to add a new student to the JSON data
app.post('/students', (req, res) => {
  const newStudent = req.body;

  // Read the existing JSON file
  fs.readFile(path.join(__dirname, 'data', 'student.json'), 'utf8', (err, data) => {
    if (err) {
      console.error("Error reading file:", err); // Log the error for debugging
      res.status(500).send('Error reading data');
      return;
    }

    // Parse the existing data and add the new student
    let jsonData;
    try {
      jsonData = JSON.parse(data);
    } catch (parseErr) {
      console.error("Error parsing JSON:", parseErr); // Log the error for debugging
      res.status(500).send('Error parsing data');
      return;
    }

    jsonData.push(newStudent);

    // Write the updated data back to the JSON file
    fs.writeFile(path.join(__dirname, 'data', 'student.json'), JSON.stringify(jsonData, null, 2), (err) => {
      if (err) {
        console.error("Error writing file:", err); // Log the error for debugging
        res.status(500).send('Error writing data');
        return;
      }
      res.status(201).send('Data added successfully');
    });
  });
});

// Define a route to fetch all students
app.get('/students', (req, res) => {
  // Read the JSON file
  fs.readFile(path.join(__dirname, 'data', 'student.json'), 'utf8', (err, data) => {
    if (err) {
      console.error("Error reading file:", err); // Log the error for debugging
      res.status(500).send('Error reading data');
      return;
    }

    res.send(data);
  });
});

// Start the server and listen on the defined port
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
